package com.example.dramaku

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.widget.LinearLayout.LayoutParams

class MainActivity : Activity() {
    private val bg = Color.rgb(15, 16, 21)
    private val panel = Color.rgb(29, 31, 40)
    private val accent = Color.rgb(255, 70, 115)
    private var selectedVideo: Uri? = null
    private lateinit var content: LinearLayout
    private lateinit var status: TextView
    private lateinit var preview: VideoView
    private lateinit var titleInput: EditText
    private lateinit var emailInput: EditText
    private lateinit var passwordInput: EditText
    private var loggedIn = false

    private val pickVideo = 42

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun base(title: String, subtitle: String? = null) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(20), dp(18), dp(20), dp(16))
        }
        val scroll = ScrollView(this).apply { isFillViewport = true }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(18))
        }
        scroll.addView(content)
        root.addView(scroll, LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(8), 0, 0)
            setBackgroundColor(bg)
        }
        nav.addView(navButton("Beranda") { showHome() }, LayoutParams(0, dp(48), 1f))
        nav.addView(navButton("Editor") { showEditor() }, LayoutParams(0, dp(48), 1f))
        nav.addView(navButton("Episode") { showEpisodes() }, LayoutParams(0, dp(48), 1f))
        nav.addView(navButton("Akun") { showLogin() }, LayoutParams(0, dp(48), 1f))
        root.addView(nav)
        setContentView(root)

        content.addView(label("DramaKu", 27, Color.WHITE, true))
        content.addView(label(title, 21, Color.WHITE, true), margin(0, 12, 0, 0))
        if (subtitle != null) content.addView(label(subtitle, 14, Color.LTGRAY), margin(0, 4, 0, 16))
    }

    private fun showHome() {
        base("Studio drama dalam genggaman", "Buat klip, pratinjau video, dan susun daftar episode.")
        val hero = TextView(this).apply {
            text = "▶\nCERITA KAMU, LAYAR KAMU"
            gravity = Gravity.CENTER
            textSize = 20f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(55, 29, 47))
            setPadding(dp(12), dp(34), dp(12), dp(34))
        }
        content.addView(hero, margin(0, 8, 0, 14))
        content.addView(label(if (loggedIn) "Hai, kreator! Kamu sudah masuk." else "Mulai dari satu adegan.", 16, Color.WHITE, true))
        content.addView(label("Lanjut menonton", 18, Color.WHITE, true), margin(0, 22, 0, 8))
        val resume = card("Video terakhir", selectedVideo?.lastPathSegment ?: "Belum ada video dipilih")
        content.addView(resume)
        content.addView(actionButton("Buka editor video") { showEditor() }, margin(0, 14, 0, 0))
        content.addView(label("Fitur utama", 18, Color.WHITE, true), margin(0, 24, 0, 8))
        content.addView(card("✂  Editor video", "Pilih video dari perangkat dan pratinjau hasilnya."))
        content.addView(card("▤  Daftar episode", "Kelola ide episode dan lanjutkan proyek drama."))
        content.addView(card("●  Login pengguna", "Mode demo lokal untuk tampilan akun."))
    }

    private fun showEditor() {
        base("Editor video", "Pilih klip, lihat pratinjau, dan tambahkan judul untuk catatan edit.")
        content.addView(actionButton("＋ Pilih video dari perangkat") { openVideoPicker() })
        status = label(selectedVideo?.toString() ?: "Belum ada video yang dipilih.", 12, Color.LTGRAY)
        content.addView(status, margin(0, 10, 0, 12))
        preview = VideoView(this).apply {
            setBackgroundColor(Color.BLACK)
            setOnErrorListener { _, _, _ ->
                Toast.makeText(this@MainActivity, "Video tidak dapat diputar pada perangkat ini.", Toast.LENGTH_SHORT).show()
                true
            }
        }
        content.addView(preview, LayoutParams(-1, dp(220)))
        selectedVideo?.let { preview.setVideoURI(it); preview.setOnPreparedListener { mp -> mp.isLooping = false } }
        val playback = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        playback.addView(actionButton("▶ Putar") { if (selectedVideo != null) preview.start() else toast("Pilih video dulu.") }, LayoutParams(0, dp(48), 1f))
        playback.addView(actionButton("Ⅱ Jeda") { if (selectedVideo != null) preview.pause() }, LayoutParams(0, dp(48), 1f))
        content.addView(playback, margin(0, 10, 0, 14))
        content.addView(label("Judul adegan", 15, Color.WHITE, true))
        titleInput = EditText(this).apply {
            hint = "Contoh: Episode 1 — Pertemuan"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            setSingleLine(true)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(panel)
        }
        content.addView(titleInput, margin(0, 6, 0, 10))
        content.addView(actionButton("Simpan catatan edit") {
            val title = titleInput.text.toString().trim()
            if (title.isEmpty()) toast("Isi judul adegan terlebih dahulu.")
            else {
                getSharedPreferences("dramaku", MODE_PRIVATE).edit().putString("last_title", title).apply()
                toast("Catatan judul disimpan: $title")
            }
        })
        content.addView(label("Catatan: versi awal ini memutar video dan menyimpan judul edit. Ekspor video dengan judul tertanam belum diimplementasikan.", 12, Color.LTGRAY), margin(0, 12, 0, 0))
    }

    private fun showEpisodes() {
        base("Daftar episode", "Contoh daftar yang bisa kamu kembangkan untuk proyek drama.")
        val episodes = listOf(
            "Episode 01" to "Pertemuan Pertama",
            "Episode 02" to "Rahasia di Balik Pintu",
            "Episode 03" to "Janji yang Tertunda"
        )
        episodes.forEachIndexed { index, item ->
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(12), dp(14), dp(12))
                setBackgroundColor(panel)
            }
            box.addView(label(item.first, 13, accent, true))
            box.addView(label(item.second, 17, Color.WHITE, true), margin(0, 4, 0, 6))
            box.addView(label(if (index == 0) "Siap dilanjutkan" else "Belum ditonton", 12, Color.LTGRAY))
            box.setOnClickListener {
                getSharedPreferences("dramaku", MODE_PRIVATE).edit().putString("last_episode", item.first).apply()
                toast("${item.first} dipilih")
                showEditor()
            }
            content.addView(box, margin(0, 8, 0, 0))
        }
        content.addView(actionButton("＋ Tambah episode (demo)") {
            val input = EditText(this).apply { hint = "Judul episode baru"; setTextColor(Color.WHITE) }
            android.app.AlertDialog.Builder(this).setTitle("Episode baru").setView(input)
                .setPositiveButton("Simpan") { _, _ ->
                    val value = input.text.toString().trim()
                    if (value.isNotEmpty()) {
                        toast("Episode '$value' dicatat untuk sesi ini.")
                    }
                }.setNegativeButton("Batal", null).show()
        }, margin(0, 14, 0, 0))
    }

    private fun showLogin() {
        base("Login pengguna", "Form demo lokal — belum terhubung ke server autentikasi.")
        if (loggedIn) {
            content.addView(card("Status akun", "Kamu sudah masuk dalam sesi aplikasi ini."))
            content.addView(actionButton("Keluar") { loggedIn = false; showLogin() })
            return
        }
        content.addView(label("Email", 14, Color.WHITE, true))
        emailInput = EditText(this).apply {
            hint = "nama@email.com"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
            setBackgroundColor(panel)
        }
        content.addView(emailInput, margin(0, 6, 0, 14))
        content.addView(label("Kata sandi", 14, Color.WHITE, true))
        passwordInput = EditText(this).apply {
            hint = "Kata sandi"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setBackgroundColor(panel)
        }
        content.addView(passwordInput, margin(0, 6, 0, 16))
        content.addView(actionButton("Masuk (demo)") {
            val email = emailInput.text.toString().trim()
            val pass = passwordInput.text.toString()
            if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches() || pass.length < 4) {
                toast("Masukkan email valid dan kata sandi minimal 4 karakter.")
            } else {
                loggedIn = true
                getSharedPreferences("dramaku", MODE_PRIVATE).edit().putString("demo_email", email).apply()
                toast("Berhasil masuk dalam mode demo.")
                showHome()
            }
        })
    }

    private fun openVideoPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "video/*"
        }
        startActivityForResult(intent, pickVideo)
    }

    @Deprecated("Legacy result callback retained for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickVideo && resultCode == RESULT_OK) {
            data?.data?.let { uri ->
                selectedVideo = uri
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                showEditor()
                toast("Video berhasil dipilih.")
            }
        }
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

    private fun card(title: String, detail: String) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(12), dp(14), dp(12))
        setBackgroundColor(panel)
        addView(label(title, 16, Color.WHITE, true))
        addView(label(detail, 13, Color.LTGRAY), margin(0, 5, 0, 0))
    }.also { it.layoutParams = margin(0, 7, 0, 0) }

    private fun actionButton(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setTextColor(Color.WHITE)
        setBackgroundTintList(android.content.res.ColorStateList.valueOf(accent))
        setOnClickListener { action() }
    }

    private fun navButton(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text
        textSize = 11f
        isAllCaps = false
        setTextColor(Color.WHITE)
        setBackgroundTintList(android.content.res.ColorStateList.valueOf(panel))
        setOnClickListener { action() }
    }

    private fun margin(l: Int, t: Int, r: Int, b: Int) =
        LayoutParams(-1, -2).apply { setMargins(dp(l), dp(t), dp(r), dp(b)) }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
