# DramaKu — Android starter project

Aplikasi Android native Kotlin dengan tema gelap.

## Fitur prototipe
- Beranda dan bagian “Lanjut menonton”.
- Pemilih video dari penyimpanan perangkat (`ACTION_OPEN_DOCUMENT`) dan pratinjau melalui `VideoView`.
- Daftar episode contoh.
- Login demo lokal (tidak mengirim kredensial ke server).
- Menyimpan catatan judul adegan secara lokal.

## Batasan versi awal
Ini adalah starter project yang dapat dibangun, bukan editor video profesional lengkap. Judul adegan disimpan sebagai catatan dan **belum dirender/ditanam ke dalam file video**. Daftar episode masih contoh, dan login belum memakai backend.

## Cara membangun APK
1. Pasang Android Studio versi terbaru yang mendukung Android Gradle Plugin 8.7.3.
2. Buka folder `DramaKu` di Android Studio.
3. Tunggu Gradle Sync; pastikan Android SDK Platform 35 terpasang.
4. Pilih **Build > Build APK(s)**.
5. APK debug biasanya tersedia di `app/build/outputs/apk/debug/app-debug.apk`.

## Paket
`com.example.dramaku`

## Ide tahap berikutnya
Tambahkan timeline trim/cut, overlay teks yang dirender ke video, audio/musik, ekspor MP4, penyimpanan proyek/episode persisten, dan autentikasi backend.
